import subprocess
import csv
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

RISKY_PORTS = {"21": "FTP", "23": "Telnet", "3389": "RDP", "445": "SMB"}

TRUSTED_RANGES = ["192.168.", "10.", "172.16."]

def is_trusted_ip(ip):
    return any(ip.startswith(trusted) for trusted in TRUSTED_RANGES)

def get_firewall_rules():
    cmd = "netsh advfirewall firewall show rule name=all"
    output = subprocess.run(cmd, capture_output=True, text=True, shell=True).stdout
    formatted_output = "\n".join([line.strip() for line in output.split("\n") if line.strip()])

    with open("firewall_rules.txt", "w", encoding="utf-8") as file:
        file.write(formatted_output)

    print("Firewall rules extracted and saved to firewall_rules.txt ✅")

    rules = []
    current_rule = {}
    for line in formatted_output.split("\n"):
        if line.startswith("Rule Name:"):
            if current_rule:
                rules.append(current_rule)
            current_rule = {"Rule Name": line.split(":", 1)[1].strip()}
        elif line.startswith("Direction:"):
            current_rule["Direction"] = line.split(":", 1)[1].strip()
        elif line.startswith("Protocol:"):
            current_rule["Protocol"] = line.split(":", 1)[1].strip()
        elif "LocalPort" in line or "Local Port" in line:
            current_rule["Local Port"] = line.split(":", 1)[1].strip()
        elif "RemoteIP" in line or "Remote IP" in line:
            current_rule["Remote IP"] = line.split(":", 1)[1].strip()
        elif line.startswith("Action:"):
            current_rule["Action"] = line.split(":", 1)[1].strip()
    if current_rule:
        rules.append(current_rule)

    df = pd.DataFrame(rules)
    df.fillna({"Direction": "Any", "Protocol": "All", "Local Port": "All Ports", "Remote IP": "Any", "Action": "Unknown"}, inplace=True)
    df.to_csv("firewall_rules.csv", index=False)
    df[df["Action"].str.contains("Allow", na=False)].to_csv("allowed_rules.csv", index=False)
    df[df["Action"].str.contains("Block", na=False)].to_csv("blocked_rules.csv", index=False)

    print("Filtered rules saved to allowed_rules.csv and blocked_rules.csv ✅")

    # --------- Visualization ---------
    print("\n📊 Firewall Rules Analysis:")
    rule_counts = df["Action"].value_counts()
    print(rule_counts)
    print("\n🔹 Protocol Distribution:\n", df["Protocol"].value_counts())

    plt.figure(figsize=(6, 4))
    sns.barplot(x=rule_counts.index, y=rule_counts.values, palette="viridis")
    plt.title("Allowed vs Blocked Firewall Rules")
    plt.xlabel("Action")
    plt.ylabel("Count")
    plt.savefig("allowed_vs_blocked.png")
    plt.show()

    plt.figure(figsize=(6, 6))
    df["Protocol"].value_counts().plot.pie(autopct="%1.1f%%", cmap="coolwarm")
    plt.title("Firewall Rules by Protocol")
    plt.ylabel("")
    plt.savefig("protocol_distribution.png")
    plt.show()

    plt.figure(figsize=(8, 5))
    df["Local Port"].replace("All Ports", None, inplace=True)
    df.dropna(subset=["Local Port"], inplace=True)
    df["Local Port"] = pd.to_numeric(df["Local Port"], errors="coerce")
    df.dropna(subset=["Local Port"], inplace=True)
    sns.histplot(df["Local Port"], bins=20, kde=True, color="royalblue")
    plt.title("Distribution of Open Ports")
    plt.xlabel("Port Number")
    plt.ylabel("Frequency")
    plt.savefig("open_ports_distribution.png")
    plt.show()

    print("\n📊 Visualizations saved as images.")

    # --------- Enhanced Recommendations ---------
    print("\n🛡️ Enhanced Firewall Rule Recommendations...")
    recommendations = []

    for _, row in df.iterrows():
        port = str(row["Local Port"])
        remote = row["Remote IP"]
        action = row["Action"]
        name = row["Rule Name"]
        issue = ""

        if port in RISKY_PORTS and "Allow" in action:
            issue += f"Allows {RISKY_PORTS[port]} (port {port}) – risky. "

        if remote.lower() == "any" and "Allow" in action:
            issue += "Allows traffic from all IPs – too open. "

        if not is_trusted_ip(remote) and "Allow" in action:
            issue += "Remote IP is not in trusted range. "

        if issue:
            recommendations.append({
                "Rule Name": name,
                "Local Port": port,
                "Remote IP": remote,
                "Action": action,
                "Issue": issue.strip()
            })

    if recommendations:
        pd.DataFrame(recommendations).to_csv("recommendations.csv", index=False)
        print("🔍 Enhanced recommendations saved to recommendations.csv ✅")
    else:
        print("✅ No risky rules found.")

get_firewall_rules()
