import subprocess
import csv
import pandas as pd

def get_firewall_rules():
    # Extracts Windows Firewall rules, formats the output, and saves it to both a text file and a CSV file.
    cmd = "netsh advfirewall firewall show rule name=all"
    output = subprocess.run(cmd, capture_output=True, text=True, shell=True).stdout

    # Format output: Remove empty lines and strip extra spaces
    formatted_output = "\n".join([line.strip() for line in output.split("\n") if line.strip()])

    # Save formatted output to a text file
    with open("firewall_rules.txt", "w", encoding="utf-8") as file:
        file.write(formatted_output)

    print("Firewall rules extracted and saved to firewall_rules.txt ✅")

    # Extract relevant details into a structured format
    rules = []
    current_rule = {}

    for line in formatted_output.split("\n"):
        if line.startswith("Rule Name:"):
            if current_rule:  # Save previous rule before starting a new one
                rules.append(current_rule)
            current_rule = {"Rule Name": line.split(":", 1)[1].strip()}
        elif line.startswith("Direction:"):
            current_rule["Direction"] = line.split(":", 1)[1].strip()
        elif line.startswith("Protocol:"):
            current_rule["Protocol"] = line.split(":", 1)[1].strip()
        elif "LocalPort" in line or "Local Port" in line:
            current_rule["Local Port"] = line.split(":", 1)[1].strip()
        elif "RemoteIP" in line or "Remote IP" in line:
            current_rule["Remote IP"] = line.split(":", 1)[1].strip()
        elif line.startswith("Action:"):
            current_rule["Action"] = line.split(":", 1)[1].strip()

    if current_rule:  # Save last rule
        rules.append(current_rule)

    # Convert to DataFrame for further processing
    df = pd.DataFrame(rules)

    # Fill missing values with default placeholders
    df.fillna({
        "Direction": "Any",
        "Protocol": "All",
        "Local Port": "All Ports",
        "Remote IP": "Any",
        "Action": "Unknown"
    }, inplace=True)

    # Save full data
    csv_filename = "firewall_rules.csv"
    df.to_csv(csv_filename, index=False)
    print(f"Firewall rules structured and saved to {csv_filename} ✅")

    # Filtering: Allowed & Blocked rules
    df[df["Action"].str.contains("Allow", na=False)].to_csv("allowed_rules.csv", index=False)
    df[df["Action"].str.contains("Block", na=False)].to_csv("blocked_rules.csv", index=False)

    print("Filtered rules saved to allowed_rules.csv and blocked_rules.csv ✅")

# Run function
get_firewall_rules()
