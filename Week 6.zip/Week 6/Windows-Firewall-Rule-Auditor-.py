import subprocess
import csv

def get_firewall_rules():
    # Extracts Windows Firewall rules, formats the output, and saves it to both a text file and a CSV file.
    cmd = "netsh advfirewall firewall show rule name=all"
    output = subprocess.run(cmd, capture_output=True, text=True, shell=True).stdout

    # Format output: Remove empty lines and strip extra spaces
    formatted_output = "\n".join([line.strip() for line in output.split("\n") if line.strip()])

    # Save formatted output to a text file
    with open("firewall_rules.txt", "w", encoding="utf-8") as file:
        file.write(formatted_output)

    print("Firewall rules extracted and saved to firewall_rules.txt ✅")

    # Extract relevant details into a structured format
    rules = []
    current_rule = {}

    for line in formatted_output.split("\n"):
        if line.startswith("Rule Name:"):
            if current_rule:  # Save previous rule before starting a new one
                rules.append(current_rule)
            current_rule = {"Rule Name": line.split(":", 1)[1].strip()}
        elif line.startswith("Direction:"):
            current_rule["Direction"] = line.split(":", 1)[1].strip()
        elif line.startswith("Protocol:"):
            current_rule["Protocol"] = line.split(":", 1)[1].strip()
        elif "LocalPort" in line or "Local Port" in line:
            current_rule["Local Port"] = line.split(":", 1)[1].strip()
        elif "RemoteIP" in line or "Remote IP" in line:
            current_rule["Remote IP"] = line.split(":", 1)[1].strip()
        elif line.startswith("Action:"):
            current_rule["Action"] = line.split(":", 1)[1].strip()

    if current_rule:  # Save last rule
        rules.append(current_rule)

    # Save extracted rules into a CSV file
    csv_filename = "firewall_rules.csv"
    with open(csv_filename, "w", newline="", encoding="utf-8") as csvfile:
        fieldnames = ["Rule Name", "Direction", "Protocol", "Local Port", "Remote IP", "Action"]
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rules)

    print(f"Firewall rules structured and saved to {csv_filename} ✅")

# Run function
get_firewall_rules()
