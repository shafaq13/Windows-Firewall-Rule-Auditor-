import subprocess
import csv
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

def get_firewall_rules():
    # Extracts Windows Firewall rules, formats the output, and saves them to text & CSV files
    cmd = "netsh advfirewall firewall show rule name=all"
    output = subprocess.run(cmd, capture_output=True, text=True, shell=True).stdout

    # Format output: Remove empty lines and strip extra spaces
    formatted_output = "\n".join([line.strip() for line in output.split("\n") if line.strip()])

    # Save formatted output to a text file
    with open("firewall_rules.txt", "w", encoding="utf-8") as file:
        file.write(formatted_output)

    print("Firewall rules extracted and saved to firewall_rules.txt ✅")

    # Extract relevant details into a structured format
    rules = []
    current_rule = {}

    for line in formatted_output.split("\n"):
        if line.startswith("Rule Name:"):
            if current_rule:  # Save previous rule before starting a new one
                rules.append(current_rule)
            current_rule = {"Rule Name": line.split(":", 1)[1].strip()}
        elif line.startswith("Direction:"):
            current_rule["Direction"] = line.split(":", 1)[1].strip()
        elif line.startswith("Protocol:"):
            current_rule["Protocol"] = line.split(":", 1)[1].strip()
        elif "LocalPort" in line or "Local Port" in line:
            current_rule["Local Port"] = line.split(":", 1)[1].strip()
        elif "RemoteIP" in line or "Remote IP" in line:
            current_rule["Remote IP"] = line.split(":", 1)[1].strip()
        elif line.startswith("Action:"):
            current_rule["Action"] = line.split(":", 1)[1].strip()

    if current_rule:  # Save last rule
        rules.append(current_rule)

    # Convert to DataFrame for further processing
    df = pd.DataFrame(rules)

    # Fill missing values with default placeholders
    df.fillna({
        "Direction": "Any",
        "Protocol": "All",
        "Local Port": "All Ports",
        "Remote IP": "Any",
        "Action": "Unknown"
    }, inplace=True)

    # Save full data
    csv_filename = "firewall_rules.csv"
    df.to_csv(csv_filename, index=False)
    print(f"Firewall rules structured and saved to {csv_filename} ✅")

    # Filtering: Allowed & Blocked rules
    df[df["Action"].str.contains("Allow", na=False)].to_csv("allowed_rules.csv", index=False)
    df[df["Action"].str.contains("Block", na=False)].to_csv("blocked_rules.csv", index=False)

    print("Filtered rules saved to allowed_rules.csv and blocked_rules.csv ✅") 

    # Data Analysis 
    
    print("\n📊 Firewall Rules Analysis:")
    
    # Count Allowed vs Blocked rules
    rule_counts = df["Action"].value_counts()
    print(rule_counts)

    # Count rules per protocol
    protocol_counts = df["Protocol"].value_counts()
    print("\n🔹 Protocol Distribution:\n", protocol_counts)

    # Visualization 

    # Bar Chart: Allowed vs Blocked Rules
    plt.figure(figsize=(6, 4))
    sns.barplot(x=rule_counts.index, y=rule_counts.values, palette="viridis")
    plt.title("Allowed vs Blocked Firewall Rules")
    plt.xlabel("Action")
    plt.ylabel("Count")
    plt.savefig("allowed_vs_blocked.png")  # Save the chart
    plt.show()

    # Pie Chart: Protocol Distribution
    plt.figure(figsize=(6, 6))
    df["Protocol"].value_counts().plot.pie(autopct="%1.1f%%", cmap="coolwarm")
    plt.title("Firewall Rules by Protocol")
    plt.ylabel("")  # Hide y-label
    plt.savefig("protocol_distribution.png")
    plt.show()

    # Histogram: Open Ports
    plt.figure(figsize=(8, 5))
    df["Local Port"].replace("All Ports", None, inplace=True)  # Remove "All Ports" for numeric analysis
    df.dropna(subset=["Local Port"], inplace=True)
    df["Local Port"] = pd.to_numeric(df["Local Port"], errors="coerce")
    df.dropna(subset=["Local Port"], inplace=True)

    sns.histplot(df["Local Port"], bins=20, kde=True, color="royalblue")
    plt.title("Distribution of Open Ports")
    plt.xlabel("Port Number")
    plt.ylabel("Frequency")
    plt.savefig("open_ports_distribution.png")
    plt.show()

    print("\n📊 Visualizations saved as images.")

# Run function
get_firewall_rules()
