import subprocess
import csv
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Function to extract and classify firewall rules
def get_firewall_rules():
    # Extract firewall rules from Windows
    cmd = "netsh advfirewall firewall show rule name=all"    
    output = subprocess.run(cmd, capture_output=True, text=True, shell=True).stdout

    # Format the raw rules
    formatted_output = "\n".join([line.strip() for line in output.split("\n") if line.strip()])
    with open("firewall_rules.txt", "w", encoding="utf-8") as file:
        file.write(formatted_output)
    print("Firewall rules extracted and saved to firewall_rules.txt ✅")

    # Extract relevant details from the raw firewall output and structure them
    rules = []
    current_rule = {}

    for line in formatted_output.split("\n"):
        if line.startswith("Rule Name:"):
            if current_rule:
                rules.append(current_rule)
            current_rule = {"Rule Name": line.split(":", 1)[1].strip()}
        elif line.startswith("Direction:"):
            current_rule["Direction"] = line.split(":", 1)[1].strip()
        elif line.startswith("Protocol:"):
            current_rule["Protocol"] = line.split(":", 1)[1].strip()
        elif "LocalPort" in line or "Local Port" in line:
            current_rule["Local Port"] = line.split(":", 1)[1].strip()
        elif "RemoteIP" in line or "Remote IP" in line:
            current_rule["Remote IP"] = line.split(":", 1)[1].strip()
        elif line.startswith("Action:"):
            current_rule["Action"] = line.split(":", 1)[1].strip()

    if current_rule:
        rules.append(current_rule)

    # Convert the list of rules to a DataFrame
    df = pd.DataFrame(rules)

    # Fill the empty values
    df.fillna({
        "Direction": "Any",
        "Protocol": "All",
        "Local Port": "All Ports",
        "Remote IP": "Any",
        "Action": "Unknown"
    }, inplace=True)

    # Save the structured rules to CSV
    df.to_csv("firewall_rules.csv", index=False)
    df[df["Action"].str.contains("Allow", na=False)].to_csv("allowed_rules.csv", index=False)
    df[df["Action"].str.contains("Block", na=False)].to_csv("blocked_rules.csv", index=False)

    print("Filtered rules saved to allowed_rules.csv and blocked_rules.csv ✅")

    # Data Analysis
    print("\n📊 Firewall Rules Analysis:")
    rule_counts = df["Action"].value_counts()
    print(rule_counts)
    print("\n🔹 Protocol Distribution:\n", df["Protocol"].value_counts())

    # Visualizations

    # Shows the Allowed and Blocked Rule Bar chart
    plt.figure(figsize=(6, 4))
    sns.barplot(x=rule_counts.index, y=rule_counts.values, palette="viridis")
    plt.title("Allowed vs Blocked Firewall Rules")
    plt.xlabel("Action")
    plt.ylabel("Count")
    plt.savefig("allowed_vs_blocked.png")
    plt.show()

    # Show the different protocol percent of rules covered
    plt.figure(figsize=(6, 6))
    df["Protocol"].value_counts().plot.pie(autopct="%1.1f%%", cmap="coolwarm")
    plt.title("Firewall Rules by Protocol")
    plt.ylabel("")
    plt.savefig("protocol_distribution.png")
    plt.show()

    # Show the frequency of the ports mostly open
    plt.figure(figsize=(8, 5))
    df["Local Port"].replace("All Ports", None, inplace=True)
    df.dropna(subset=["Local Port"], inplace=True)
    df["Local Port"] = pd.to_numeric(df["Local Port"], errors="coerce")
    df.dropna(subset=["Local Port"], inplace=True)

    sns.histplot(df["Local Port"], bins=20, kde=True, color="royalblue")
    plt.title("Distribution of Open Ports")
    plt.xlabel("Port Number")
    plt.ylabel("Frequency")
    plt.savefig("open_ports_distribution.png")
    plt.show()

    print("\n📊 Visualizations saved as images.")

    # Audit Checklist Matching & Flagging 
    print("\n🛡️ Generating Firewall Rule Audit Flags...")

    # Risky ports (i.e unencrypted, Window Sharing, remote access etc.)
    risky_ports = {"21": "FTP", "23": "Telnet", "3389": "RDP", "445": "SMB"}
    
    # Overly permissive IP ranges
    high_risk_remote = ["Any", "0.0.0.0/0", "*"]  # Allow any access

    # Trusted IP addresses (you can modify this list with trusted IPs)
    trusted_ips = ["192.168.1.100", "10.0.0.1", "172.16.5.5"] 

    # Initialize an empty list for audit flags
    audit_flags = []
    recommendations = []

    for _, row in df.iterrows():
        flag = "Compliant"  # Default flag
        recommendation = "No action needed"

        port = str(row.get("Local Port", "")).strip()
        remote_ip = str(row.get("Remote IP", "")).strip()
        action = str(row.get("Action", "")).strip()

        # Flag rules based on risky ports or overly permissive access
        if remote_ip in trusted_ips:
            flag = "Low Risk"
            recommendation = "Trusted IP, no action needed"
        
        elif remote_ip not in trusted_ips:
            flag = "High Rick"
            recommendation = "Restrict remote IP access"
        
        elif port in risky_ports and "Allow" in action:
            flag = "High Risk"
            recommendation = f"Block port {port} ({risky_ports[port]})"
        
        elif remote_ip in high_risk_remote and "Allow" in action:
            flag = "Moderate Risk"
            recommendation = "Restrict remote IP access"

        elif remote_ip in high_risk_remote and "Allow" in action and port in risky_ports:
            flag = "High Risk"
            recommendation = f"Block port {port} ({risky_ports[port]}) and restrict remote IP access"

        audit_flags.append(flag)
        recommendations.append(recommendation)

    # Add the audit flags and recommendations to the dataframe
    df["Audit Flag"] = audit_flags
    df["Recommendation"] = recommendations

    # Save the updated rules with audit flags and recommendations
    df.to_csv("audit_flagged_recommended_rules.csv", index=False)

    print("✅ Audit flags and recommendations assigned and saved to audit_flagged_recommended_rules.csv")

# Run function to extract, classify, analyze, and audit firewall rules
get_firewall_rules()
