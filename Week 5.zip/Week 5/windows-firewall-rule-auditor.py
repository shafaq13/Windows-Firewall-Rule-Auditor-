import subprocess

# Extract and formate the windows firewall rules 
def get_firewall_rules():
    # Retrieves all firewall rules, including allowed apps, blocked apps, open ports, protocols, and IP addresses.
    cmd = "netsh advfirewall firewall show rule name=all"  
    output = subprocess.run(cmd, capture_output=True, text=True, shell=True).stdout # run the command and capture output

    # formated output
    f_output = "\n".join([line.strip() for line in output.split("\n") if line.strip()])
    
    # save the formated output into the file
    with open("firewall_rules.txt", "w", encoding="utf-8") as file:
        file.write(f_output)
    
    return output

firewall_rules = get_firewall_rules()
print("Firewall rules extracted and saved to firewall_rules.txt ✅")
